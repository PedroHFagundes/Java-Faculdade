public class Dataclasse {
    
    //atributo 
   private int dia;
   private int mes;
   private int ano;
   private String dataExtenso;
   
       
       
        public Dataclasse(){
            this.dia = 0;
            this.mes = 0;
            this.ano = 0;
            
        }


        public int definirDia(int dia){
            this.dia  = dia;
            return dia;
        }
        public int definirMes(int mes){
            this.mes  = mes;
            return mes;
        }
        public int definirAno(int ano){
            this.ano  = ano;
            return ano;
        }


        public void imprimir(){
            if(this.dia < 10 || this.mes < 10){
                System.out.println("0" + this.dia + "/" + "0" + this.mes +  "/" + this.ano);
            }else{
                System.out.println("" + this.dia + "/" + "" + this.mes +  "/" + "" + this.ano);
            }
        }

        public String imprimirExtenso(String extenso){
            this.dataExtenso = extenso;
            System.out.println("  "  + dataExtenso);
            return dataExtenso;
        }


        public String Extenso(){
            String extendia = "Indefinido";
            String extenmes = "Indefinido";
            String extenano = Integer.toString(this.ano);
            switch(this.dia){
                case 1:
                    extendia = "Um";
                    break;
                case 2:
                    extendia = "Dois";
                    break;
                case 3:
                    extendia = "Três";
                    break;
                case 4:
                    extendia = "Quatro";
                    break;
                case 5:
                    extendia = "Cinco";
                    break;
                case 6:
                    extendia = "Seis";
                    break;
                case 7:
                    extendia = "Sete";
                    break;
                case 8:
                    extendia = "Oito";
                    break;
                case 9:
                    extendia = "Nove";
                    break;
                case 10:
                    extendia = "Dez";
                    break;
                case 11:
                    extendia = "Onze";
                    break;
                case 12:
                    extendia = "Doze";
                    break;
                case 13:
                    extendia = "Treze";
                    break;
                case 14:
                    extendia = "Catorze";
                    break;
                case 15:
                    extendia = "Quinze";
                    break;
                case 16:
                    extendia = "Desesseis";
                    break;
                case 17:
                    extendia = "Dessesete";
                    break;
                case 18:
                    extendia = "Desoito";
                    break;
                case 19:
                    extendia = "Desenove";
                    break;
                case 20:
                    extendia = "Vinte";
                    break;
                case 21:
                    extendia = "Vinte e um";
                    break;
                case 22:
                    extendia = "Vinte e dois";
                    break;
                case 23:
                    extendia = "Vinte e três";
                    break;
                case 24:
                    extendia = "Vinte e quatro";
                    break;
                case 25:
                    extendia = "Vinte e cinco";
                    break;
                case 26:
                    extendia = "Vinte e seis";
                    break;
                case 27:
                    extendia = "Vinte e sete";
                    break;
                case 28:
                    extendia = "Vinte e oito";
                    break;
                case 29:
                    extendia = "Vinte e nove";
                    break;
                case 30:
                    extendia = "Trinta";
                    break;
                case 31:
                    extendia = "Trinta e um";
                    break;
                default:
                    System.out.println ("O valor do dia eh invalido");
                    break;
                
            }
    
            switch(this.mes){
                case 1:
                    extenmes = "Janeiro";
                    break;
                case 2:
                    extenmes = "Fevereiro";
                    break;
                case 3:
                    extenmes = "Março";
                    break;
                case 4:
                    extenmes = "Abril";
                    break;
                case 5:
                    extenmes = "Maio";
                    break;
                case 6:
                    extenmes = "Junho";
                    break;
                case 7:
                    extenmes = "Julho";
                    break;
                case 8:
                    extenmes = "Agosto";
                    break;
                case 9:
                    extenmes = "Setembro";
                    break;
                case 10:
                    extenmes = "Outubro";
                    break;
                case 11:
                    extenmes = "Novembro";
                    break;
                case 12:
                    extenmes = "Dezembro";
                    break;
                default:
                    System.out.println ("O valor do mes eh invalido");
                    break;
                
            }
    
            String dataExtenso = (extendia + " de " + extenmes + " de " + extenano);
            return dataExtenso;
            }
}
