public class dataobjeto{
    public static void main(String[] args) {
       Dataclasse data = new Dataclasse();

     data.definirDia(8);
     data.definirMes(2);
     data.definirAno(2002);

         data.imprimir();
         
       System.out.println(data.Extenso());


    }
}
