public class Pessoacls {
    // atributos
    private int cpf;
    private String nome;
    private int celular;
    private String email;

    public Pessoacls() {
        this.cpf = 0;
        this.nome = "Indefinido";
        this.celular = 0;
        this.email = "Indefinido";
    }

    public void mostarDados() {
        System.out.println("CPF:" + this.cpf);
        System.out.println("Nome:" + this.nome);
        System.out.println("Celular:" + this.celular);
        System.out.println(" Email:" + this.email);
    }

    public void definirDados(int cpf, String nome, int celular, String email) {
        this.cpf = cpf;
        this.nome = nome;
        this.celular = celular;
        this.email = email;
    }

}
