public class Pessoas {
    public static void main(String[] args) {
        Pessoacls pessoa = new Pessoacls();

        pessoa.mostarDados();

        pessoa.definirDados(1123241, "Pedro Henrique Fagundes", 998251401, "pedraohf@hotmail.com");

        System.out.println("\n\n");

        pessoa.mostarDados();

    }
}
